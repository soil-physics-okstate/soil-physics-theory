#PSP_refinement
from __future__ import print_function, division
from PSP_utility import *
from PSP_Delaunay import *
import PSP_triangle as triangle
import PSP_visual3D as visual3D

REFINEMENT_Z = 1
REFINEMENT_ANGLE = 2

def requireRefinement(header, dtm, flag, myTriangle, threshold, step):
    plane = triangle.getPlane(myTriangle.v)
    rect = triangle.getRectangle(myTriangle.v)
    colMin, rowMin = getColRowFromXY(header, rect.x0, rect.y1)
    colMax, rowMax = getColRowFromXY(header, rect.x1, rect.y0)
    dzMax = 0.0
    for col in np.arange(colMin, colMax+1, step):
        for row in np.arange(rowMin, rowMax+1, step):
            if isTrue(header, flag, col, row):
                p = getPointFromColRow(header, dtm, col, row)
                if triangle.isPointInside(p, myTriangle.v):
                    x, y, z = p
                    zPlane = triangle.getZplane(plane, x, y)
                    dz = fabs(z - zPlane)
                    if (dz > dzMax): 
                        dzMax = dz
                        newPointRow = row
                        newPointCol = col    
    if (dzMax < threshold):
        return False, NODATA, NODATA 
    else:
        return True, newPointCol, newPointRow
    
    
def refinement(triangleList, newPoint, header, dtm, currentIndex, myType):
    #initialize 
    deleteList = []
    vertexList = []
    angleList = []
    newTriangles = []
    checkList = []
    
    currentTriangle = triangleList[currentIndex]
    if myType == REFINEMENT_ANGLE:
        isInside = triangle.isPointInside(newPoint, currentTriangle.v)
        
    deleteList.append(currentIndex)
    for i in range(3):
        insertVertexClockwise(currentTriangle.v[i], 
                newPoint, vertexList, angleList)
    
    for i in range(len(triangleList)):
        if (i != currentIndex): 
            myTriangle = triangleList[i]
            dx = newPoint[0] - myTriangle.circle.x
            if (dx <= myTriangle.circle.radius):
                dy = newPoint[1] - myTriangle.circle.y
                if (dy <= myTriangle.circle.radius):
                    if (((dx * dx) + (dy * dy)) <= myTriangle.circle.radiusSquared): 
                        checkList.append(i)         
    i = 0
    while (i < len(checkList)):                
        index = checkList[i]
        myTriangle = triangleList[index] 
        if  triangle.isAdjacent(myTriangle.v, vertexList):
            for j in range(3):
                insertVertexClockwise(myTriangle.v[j], 
                            newPoint, vertexList, angleList) 
            if myType == REFINEMENT_ANGLE and (not isInside):
                isInside = triangle.isPointInside(newPoint, myTriangle.v)
            orderedInsert(index, deleteList)
            checkList.pop(i)
            i = 0 
        else: i+=1 
            
    if myType == REFINEMENT_ANGLE and (not isInside): return NODATA 
    
    # create new triangles
    nrVertices = len(vertexList) 
    for i in range(nrVertices):
        v = np.zeros((3, 3), float)
        v[0] = newPoint
        v[1] = vertexList[i]
        v[2] = vertexList[(i+1) % nrVertices] 
        myTriangle = triangle.Ctriangle(v)
        if myTriangle.circle.isCorrect:
            newTriangles.append(myTriangle)
        else:
            return NODATA
    
    if len(newTriangles) <= len(deleteList): return NODATA
    
    firstIndex = deleteList[0]
    for i in range(len(deleteList)-1, -1, -1):
        triangleList.pop(deleteList[i])
        visual3D.delTriangle(deleteList[i])
    
    for i in range(len(newTriangles)):
        myTriangle = newTriangles[i]  
        triangleList.insert(firstIndex+i, myTriangle)
        visual3D.addTriangle(firstIndex+i, myTriangle, header)                       
    return firstIndex 

            
def refinementZ(pointList, triangleList, header, dtm, threshold, areaMin, flagMatrix, step):
    print ("Z refinement...")
    currentIndex = 0
    while currentIndex < len(triangleList):
        myTriangle = triangleList[currentIndex] 
        isRefinement = False
        if not myTriangle.isRefinedZ:
            if triangle.getArea2D(myTriangle.v) > areaMin:
                isRequire, newCol, newRow = requireRefinement(header, 
                                        dtm, flagMatrix, myTriangle, threshold, step)
                if isRequire:
                    newPoint = getPointFromColRow(header, dtm, newCol, newRow)
                    newIndex = refinement(triangleList, newPoint, header, 
                                              dtm, currentIndex, REFINEMENT_Z)
                    if newIndex != NODATA:
                        isRefinement = True
                        pointList.append(newPoint)
                        flagMatrix = updateFlagMatrix(flagMatrix, header, newCol, newRow, step)
                        currentIndex = newIndex
                        
        triangleList[currentIndex].isRefinedZ = True
        if not isRefinement: currentIndex += 1
    
    pointList = sortPointList(pointList)          
    return pointList, triangleList, flagMatrix
    
    
def refinementAngle(pointList, triangleList, header, dtm, angleThreshold, areaMin, flagMatrix, step):
    print ("angle refinement...")
    currentIndex = 0
    while currentIndex < len(triangleList):
        myTriangle = triangleList[currentIndex]
        isRefinement = False
        if not myTriangle.isRefinedAngle:
            if triangle.getMinAngle(myTriangle.v) < angleThreshold:
                if triangle.getArea2D(myTriangle.v) > areaMin:
                    newCol, newRow = getColRowFromXY(header, 
                            myTriangle.circle.x, myTriangle.circle.y)
                    if isTrue(header, flagMatrix, newCol, newRow):
                        newPoint = getPointFromColRow(header, dtm, newCol, newRow)
                        newIndex = refinement(triangleList, newPoint, 
                                         header, dtm, currentIndex, REFINEMENT_ANGLE)
                        if newIndex != NODATA:
                            isRefinement = True
                            pointList.append(newPoint)
                            flagMatrix = updateFlagMatrix(flagMatrix, header, newCol, newRow, step)
                            currentIndex = newIndex
                            
        triangleList[currentIndex].isRefinedAngle = True
        if not isRefinement: currentIndex += 1
            
    pointList = sortPointList(pointList)           
    return pointList, triangleList, flagMatrix
